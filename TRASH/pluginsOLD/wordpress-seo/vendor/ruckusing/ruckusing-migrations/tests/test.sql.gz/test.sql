DROP DATABASE IF EXISTS ruckusing_migrations_test; 
CREATE DATABASE ruckusing_migrations_test;
